﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Bank_Accounts.Migrations
{
    public partial class EigthMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
