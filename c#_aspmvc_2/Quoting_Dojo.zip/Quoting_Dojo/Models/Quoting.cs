using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;

namespace Quoting_Dojo.Models
{
    public class Quoting
    {
        public string Name{get;set;}
        public string Quote{get;set;}
    }
}