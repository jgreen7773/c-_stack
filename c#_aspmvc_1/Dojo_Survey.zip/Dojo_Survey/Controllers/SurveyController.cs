using Microsoft.AspNetCore.Mvc;
namespace Dojo_Survey
{
    public class SurveyController : Controller
    {

        [HttpGet]
        [Route("")]
        public ViewResult RequestSurvey()
        {
            return View("RequestSurvey");
        }
        
        [HttpPost]
        [Route("displaysurvey")]
        public IActionResult DisplaySurvey(string name, string location, string language, string comment)
        {
            ViewBag.displayname = name;
            ViewBag.displaylocation = location;
            ViewBag.displaylanguage = language;
            ViewBag.displaycomment = comment;
            return View("DisplaySurvey");
        }
    }
}