using Microsoft.AspNetCore.Mvc;
namespace Portfolio
{
    public class PortfolioController : Controller
    {
        [Route("")]
        [HttpGet]
        public string Index()
        {
            return "This is my index!";
        }

        [Route("projects")]
        [HttpGet]
        public string projects()
        {
            return "These are my projects!";
        }

        [Route("contact")]
        [HttpGet]
        public string contact()
        {
            return "This is my contact!";
        }
    }
}